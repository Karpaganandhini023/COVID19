-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2020 at 08:27 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gcm`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `password`, `created_at`) VALUES
(1, 'TN', '123', '2017-05-24'),
(0, 'admin', '123', NULL),
(0, 'TN', '123', NULL),
(0, 'admin', '123', NULL),
(0, 'admin', '123', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE IF NOT EXISTS `appointments` (
  `id` int(11) NOT NULL,
  `doctor_name` varchar(30) NOT NULL,
  `patient_name` varchar(30) NOT NULL,
  `notice_date` date NOT NULL,
  `notice_time` time NOT NULL,
  `description` text NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `doctor_name`, `patient_name`, `notice_date`, `notice_time`, `description`, `status`) VALUES
(1, 'Suresh', 'ABC', '2020-05-22', '10:01:00', 'I have severe headache', 'seen'),
(2, 'Gopi', 'XYZ', '2020-04-16', '09:01:00', 'I have fever and running nose', 'Unseen'),
(3, 'Raj', 'YIU', '2020-03-19', '07:01:00', 'I have complexity in breathing', 'seen'),
(4354, 'Suresh', 'PARAGATI', '2020-05-13', '17:30:00', 'yhgefwd', 'Seen'),
(0, '', '', '0000-00-00', '00:00:00', '', ''),
(201, 'Raj', 'Yourname', '2020-05-06', '15:30:00', 'nhbgefvdc', 'Unseen'),
(12, 'Suresh', 'PARAGATI', '2020-05-05', '15:30:00', 'I have headache', 'Unseen'),
(12, 'Suresh', 'Jharkand', '2020-05-20', '10:30:00', 'nhbgfvdcx ', 'Seen'),
(13, 'Raj', '101', '2020-05-06', '10:30:00', 'I have severe headache and running nose', 'Seen'),
(0, '', '', '0000-00-00', '00:00:00', '', ''),
(12, 'Suresh', 'PARAGATI', '2020-05-04', '09:30:00', 'I have cough and sneezing problem', 'Seen'),
(12, 'Suresh', 'wedsfvd', '2020-05-14', '10:30:00', 'ikujyhtgf', 'Seen'),
(0, '', '', '0000-00-00', '00:00:00', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `doctorsa`
--

CREATE TABLE IF NOT EXISTS `doctorsa` (
  `p_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `dname` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `create_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorsa`
--

INSERT INTO `doctorsa` (`p_id`, `doctor_id`, `dname`, `status`, `create_date`) VALUES
(1001, 301, 'Suresh', 'avaialable', '2020-03-19'),
(1002, 302, 'Raj', 'Unavaialable', '2020-04-07'),
(1003, 303, 'Gopi', 'avaialable', '2020-05-24');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
  `p_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `doctor_name` varchar(30) NOT NULL,
  `patient_name` varchar(30) NOT NULL,
  `status` varchar(30) NOT NULL,
  `Zone` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`p_id`, `doctor_id`, `doctor_name`, `patient_name`, `status`, `Zone`) VALUES
(1001, 301, 'Gopi', 'srt', 'Checked', 'orange'),
(1002, 302, 'suresh', 'xyz', 'unchecked', 'orange'),
(1003, 303, 'suresh', 'abc', 'Checked', 'orange'),
(8, 0, 'Suresh', 'Jonson12', '', ''),
(5, 1003, 'Suresh', 'Abc', 'normal', 'Orange'),
(876, 567, 'Suresh', 'Aswath', 'middle', 'Orange'),
(98765, 3, 'Suresh', 'Abc', 'normal', 'Orange'),
(1001, 2, 'gopi', 'XYZ', 'middle', 'RED'),
(0, 0, '', '', '', ''),
(1001, 5, 'raj', 'Firstname', 'normal', 'Orange'),
(0, 0, '', '', '', ''),
(0, 0, '', '', '', ''),
(0, 0, '', '', '', ''),
(76534, 2345, 'Suresh', 'Jonson12', 'normal', ''),
(1001, 3, 'gopi', 'Patient name', 'normal', ''),
(0, 0, '', '', '', ''),
(1101, 3001, 'gopi', 'Aswath', 'normal', ''),
(101, 201, 'Gopi', 'Patientname', 'normal', ''),
(302, 101, 'Raj', 'XXX', 'normal', 'RED'),
(101, 1, 'Raj', 'Jharkand', 'normal', 'Orange'),
(12, 123, 'Suresh', 'nbvcvx', 'middle', 'RED'),
(0, 0, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `volunteer`
--

CREATE TABLE IF NOT EXISTS `volunteer` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `Volunteer_Name` varchar(20) NOT NULL,
  `district_name` varchar(30) NOT NULL,
  `vadate` date NOT NULL,
  `vatime` time(2) NOT NULL,
  `ActivityDescription` varchar(30) NOT NULL,
  `vstatus` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `volunteer`
--

INSERT INTO `volunteer` (`id`, `Volunteer_Name`, `district_name`, `vadate`, `vatime`, `ActivityDescription`, `vstatus`) VALUES
(19, '', 'Ranchi', '2020-05-10', '15:30:00.00', 'xdgfchvjbkn', 'Finished'),
(20, '', 'Ranchi', '2020-05-10', '15:30:00.00', 'xdgfchvjbkn', 'Finished'),
(21, '', '', '0000-00-00', '00:00:00.00', '', ''),
(22, '', 'Ranchi', '2020-05-08', '10:30:00.00', 'jmhnbgvc', 'Finished'),
(23, '', 'Ranchi', '2020-05-08', '10:30:00.00', 'jmhnbgvc', 'Finished'),
(24, '', '', '0000-00-00', '00:00:00.00', '', ''),
(25, 'NON-GOVT', 'Ranchi', '2020-05-04', '13:30:00.00', 'hnbgvfc', 'Finished'),
(26, '', '', '0000-00-00', '00:00:00.00', '', ''),
(27, 'volunteer_name', 'Simdega', '2020-05-05', '10:45:00.00', 'nbtvrcex', 'Finished'),
(28, '', '', '0000-00-00', '00:00:00.00', '', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
