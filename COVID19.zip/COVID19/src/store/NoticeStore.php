<?php
$con=mysqli_connect('localhost:3308','root','','gcm');
$id=$_GET['PatientId'];
$doctor_name=$_GET['doctor_name'];
$patient_name=$_GET['patientname'];
$notice_date=$_GET['apdate'];
$notice_time=$_GET['aptime'];
$description=$_GET['Description'];
$status=$_GET['status'];
$sql="INSERT INTO appointments(id,doctor_name,patient_name,notice_date,notice_time,description,status)
 VALUES('$id','$doctor_name','$patient_name','$notice_date','$notice_time','$description','$status')";
if(!mysqli_query($con,$sql))
{
echo "Not inserted";
}
else
{
echo "Inserted";
}
$select="Select * from appointments";
$result= mysqli_query($con, $select);
$count= mysqli_num_rows($result);
$dbvalue="";
if($count < 1)
{
	echo "No more rows";
}
else
{
	echo'has rows';
}

    if($result) {
        header("Location: " ."../../views/admin/sendNotice.php?message=success");
        die();
    } else {
        header("Location: " ."../../views/admin/sendNotice.php?message=failed");
        die();
    }

class NoticeStore
{

}
?>