﻿<?php

session_start();

if(!isset($_SESSION['admin_name']) && !isset($_SESSION['password'])) {
    header("Location:../../index.php");
}

include ("../../src/common/DBConnection.php");

$conn=new DBConnection();



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>COVID 19 MANAGEMENT</title>

    <!-- Bootstrap -->
    <link href="../../resource/css/bootstrap.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../../resource/css/font-awesome.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../../resource/css/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="../../resource/css/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="../../resource/css/bootstrap-progressbar-3.3.4.css" rel="stylesheet">
    <!-- JQVMap -->
    <link href="../../resource/css/jqvmap.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="../../resource/css/daterangepicker.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../../resource/css/custom.css" rel="stylesheet">
</head>

<body class="nav-md">
<div class="container body">
    <div class="main_container">

        <!-- side and top bar include -->
        <?php include '../partPage/sideAndTopBarMenu.html' ?>
        <!-- /side and top bar include -->

        <!-- page content -->
        <div class="right_col" role="main">
            <!-- top tiles -->
            <div class="row tile_count">
                <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
                    <span class="count_top"><i class="fa fa-user"></i> Total Live Cases in India</span>
                    <div class="count">5.21M</div>
                    <span class="count_bottom"><i class="green">4% </i> Increase from last Week</span>
                </div>
                <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
                    <span class="count_top"><i class="fa fa-clock-o"></i> Total Recovered Cases in India</span>
                    <div class="count">4.03M</div>
                    <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>3% </i> From last Week</span>
                </div>
                <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
                    <span class="count_top"><i class="fa fa-user"></i>Total deaths in India</span>
                    <div class="count">84372</div>
                    <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span>
                </div>
                <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
                    <span class="count_top"><i class="fa fa-user"></i>Total Cases Active in Jharkand</span>
                    <div class="count green">67100</div>
                    <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span>
                </div>
                <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
                    <span class="count_top"><i class="fa fa-user"></i> Total Recovered in Jharkand</span>
                    <div class="count">52807</div>
                    <span class="count_bottom"><i class="red"><i class="fa fa-sort-desc"></i>12% </i> From last Week</span>
                </div>
                <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count">
                    <span class="count_top"><i class="fa fa-user"></i>Total deaths in Jharkand</span>
                    <div class="count">590</div>
                    <span class="count_bottom"><i class="green"><i class="fa fa-sort-asc"></i>34% </i> From last Week</span>
                </div>
               
            </div>
            <!-- /top tiles -->

<div class="TbwUpd NJjxre"><cite class="iUh30 bc tjvcx">www.worldometers.info<span class="eipWBe"> &rsaquo; coronavirus</span></cite></div></a>
<table class="nrgt" cellpadding="0" cellspacing="0"><tr class="mslg dmenKe"><td><!--m--><div class="sld vsc"><span class="cNifBc">
<h3 class="r"><a class="l" href="https://www.worldometers.info/coronavirus/?utm_campaign=homeAdvegas1?" data-ved="2ahUKEwi51JvLlcLqAhXKyTgGHXcCC50QjBAwBXoECAgQAg" ping="/url?sa=t&amp;source=web&amp;rct=j&amp;url=https://www.worldometers.info/coronavirus/%3Futm_campaign%3DhomeAdvegas1%3F&amp;ved=2ahUKEwi51JvLlcLqAhXKyTgGHXcCC50QjBAwBXoECAgQAg">Coronavirus Cases</a></h3></span><div class="s"><div class="st" style="overflow:hidden;width:220px">Live statistics and coronavirus news tracking the number of ...<br></div></div></div><!--n--></td><td><!--m-->
<div class="sld vsc"><span class="cNifBc">
<h3 class="r"><a class="l" href="https://www.worldometers.info/coronavirus/country/us/" data-ved="2ahUKEwi51JvLlcLqAhXKyTgGHXcCC50QjBAwCHoECAgQBA" ping="/url?sa=t&amp;source=web&amp;rct=j&amp;url=https://www.worldometers.info/coronavirus/country/us/&amp;ved=2ahUKEwi51JvLlcLqAhXKyTgGHXcCC50QjBAwCHoECAgQBA">The United States</a></h3></span>
<div class="s"><div class="st" style="overflow:hidden;width:220px">California&nbsp;- Texas&nbsp;- Florida&nbsp;- New York&nbsp;- Pennsylvania&nbsp;- New Jersey<br></div></div></div><!--n--></td></tr><tr class="mslg"><td><!--m--><div class="sld vsc"><span class="cNifBc"><h3 class="r">
<a class="l" href="https://www.worldometers.info/coronavirus/country/india/" data-ved="2ahUKEwi51JvLlcLqAhXKyTgGHXcCC50QjBAwBnoECAgQBg" ping="/url?sa=t&amp;source=web&amp;rct=j&amp;url=https://www.worldometers.info/coronavirus/country/india/&amp;ved=2ahUKEwi51JvLlcLqAhXKyTgGHXcCC50QjBAwBnoECAgQBg">India</a></h3></span>
<div class="s"><div class="st" style="overflow:hidden;width:220px">India Coronavirus update with statistics and graphs: total and ...<br></div></div></div><!--n--></td><td>
<!--m-->
<div class="sld vsc"><span class="cNifBc"><h3 class="r"><a class="l" href="https://www.worldometers.info/coronavirus/country/brazil/" data-ved="2ahUKEwi51JvLlcLqAhXKyTgGHXcCC50QjBAwCXoECAgQCA" ping="/url?sa=t&amp;source=web&amp;rct=j&amp;url=https://www.worldometers.info/coronavirus/country/brazil/&amp;ved=2ahUKEwi51JvLlcLqAhXKyTgGHXcCC50QjBAwCXoECAgQCA">Brazil</a></h3></span><div class="s"><div class="st" style="overflow:hidden;width:220px">Brazil Coronavirus update with statistics and graphs: total and ...<br></div></div></div><!--n--></td></tr><tr class="mslg"><td><!--m--><div class="sld vsc"><span class="cNifBc"><h3 class="r"><a class="l" href="https://www.worldometers.info/coronavirus/country/south-africa/" data-ved="2ahUKEwi51JvLlcLqAhXKyTgGHXcCC50QjBAwB3oECAgQCg" ping="/url?sa=t&amp;source=web&amp;rct=j&amp;url=https://www.worldometers.info/coronavirus/country/south-africa/&amp;ved=2ahUKEwi51JvLlcLqAhXKyTgGHXcCC50QjBAwB3oECAgQCg">South Africa</a></h3></span><div class="s"><div class="st" style="overflow:hidden;width:220px">South Africa Coronavirus update with statistics and graphs: total ...<br></div></div></div><!--n--></td><td><!--m--><div class="sld vsc"><span class="cNifBc"><h3 class="r"><a class="l" href="https://www.worldometers.info/coronavirus/country/italy/" data-ved="2ahUKEwi51JvLlcLqAhXKyTgGHXcCC50QjBAwCnoECAgQDA" ping="/url?sa=t&amp;source=web&amp;rct=j&amp;url=https://www.worldometers.info/coronavirus/country/italy/&amp;ved=2ahUKEwi51JvLlcLqAhXKyTgGHXcCC50QjBAwCnoECAgQDA">Italy</a></h3></span><div class="s"><div class="st" style="overflow:hidden;width:220px">Italy Coronavirus update with statistics and graphs: total and ...<br></div></div></div><!--n--></td></tr><tr><td class="H3TZoe GBzFvf" colspan="2"><div class="vLK3gc"><a class="fl" href="/search?q=corona+cases+update+site:worldometers.info+&amp;rlz=1C1CHZL_enIN823IN823&amp;sxsrf=ALeKk003sq-IseK8Q0WJTRIfnbfit07mag:1594366374642&amp;sa=X&amp;ved=2ahUKEwi51JvLlcLqAhXKyTgGHXcCC50QrAN6BAgGEAU"


            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="dashboard_graph">

                        <div class="row x_title">
                            <div class="col-md-6">
                                <h3>COVID 19 Statistics<small>Graph title sub-title</small></h3>
                            </div>
                            <div class="col-md-6">
                                <div id="reportrange" class="pull-right" style="background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #ccc">
                                    <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>
                                    <span>March 16, 2020 - May 17, 2020</span> <b class="caret"></b>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-9 col-sm-9 col-xs-12">
                            <iframe src="https://public.domo.com/cards/epNEr" width="90%" height="600" marginheight="0" marginwidth="0" frameborder="0"></iframe>
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-12 bg-white">
                            <div class="x_title">
                                <h2>Graphical data on COVID 19 CASES</h2>
                                <div class="clearfix"></div>
                            </div>

                            <div class="col-md-12 col-sm-12 col-xs-6">
                                <div>
                                    <p>Cases as of April 2</p>
                                    <div class="">
                                        <div class="progress progress_sm" style="width: 20%;">
                                            <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="80"></div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <p>Cases as of May 2</p>
                                    <div class="">
                                        <div class="progress progress_sm" style="width: 40%;">
                                            <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="60"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 col-sm-12 col-xs-6">
                                <div>
                                    <p>Cases as of July2</p>
                                    <div class="">
                                        <div class="progress progress_sm" style="width: 75%;">
                                            <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="40"></div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <p>Cases as of August2</p>
                                    <div class="">
                                        <div class="progress progress_sm" style="width: 90%;">
                                            <div class="progress-bar bg-green" role="progressbar" data-transitiongoal="50"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="clearfix"></div>
                    </div>
                </div>

            </div>
            <br />

            <div class="row">


                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="x_panel tile fixed_height_320">
                        <div class="x_title">
                            <h2>Civil Supplies</h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="#">Settings 1</a>
                                        </li>
                                        <li><a href="#">Settings 2</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a class="close-link"><i class="fa fa-close"></i></a>
                                </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <h4>Civil Supply Information in Jharkand</h4>
                            <div class="widget_summary">
                                <div class="w_left w_25">
                                    <span>AAY Card Holders</span>
                                </div>
                                <div class="w_center w_55">
                                    <div class="progress">
                                        <div class="progress-bar bg-green" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 66%;">
                                            <span class="sr-only">85% Complete</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="w_right w_20">
                                    <span>85%</span>
                                </div>
                                <div class="clearfix"></div>
                            </div>

                            <div class="widget_summary">
                                <div class="w_left w_25">
                                    <span>PHH Card holders</span>
                                </div>
                                <div class="w_center w_55">
                                    <div class="progress">
                                        <div class="progress-bar bg-green" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 45%;">
                                            <span class="sr-only">76% Complete</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="w_right w_20">
                                    <span>76%</span>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="widget_summary">
                                <div class="w_left w_25">
                                    <span>Rice to AAY</span>
                                </div>
                                <div class="w_center w_55">
                                    <div class="progress">
                                        <div class="progress-bar bg-green" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 25%;">
                                            <span class="sr-only">71% Complete</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="w_right w_20">
                                    <span>71%
</span>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="widget_summary">
                                <div class="w_left w_25">
                                    <span>Rice to PHH</span>
                                </div>
                                <div class="w_center w_55">
                                    <div class="progress">
                                        <div class="progress-bar bg-green" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 5%;">
                                            <span class="sr-only">61% Complete</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="w_right w_20">
                                    <span>61%</span>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="widget_summary">
                                <div class="w_left w_25">
                                    <span>Truck Challans for FPS</span>
                                </div>
                                <div class="w_center w_55">
                                    <div class="progress">
                                        <div class="progress-bar bg-green" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 2%;">
                                            <span class="sr-only">94% Complete</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="w_right w_20">
                                    <span>94%</span>
                                </div>
                                <div class="clearfix"></div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="x_panel tile fixed_height_320 overflow_hidden">
                        <div class="x_title">
                            <h2>Quarantined Data</h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="#">Settings 1</a>
                                        </li>
                                        <li><a href="#">Settings 2</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a class="close-link"><i class="fa fa-close"></i></a>
                                </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <table class="" style="width:100%">
                                <tr>
                                    <th style="width:37%;">
                                        <p>Top 5</p>
                                    </th>
                                    <th>
                                        <div class="col-lg-7 col-md-7 col-sm-7 col-xs-7">
                                            <p class="">Places in Goa</p>
                                        </div>
                                        <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">
                                            <p class="">Quarantined details</p>
                                        </div>
                                    </th>
                                </tr>
                                <tr>
                                    <td>
                                        <canvas class="canvasDoughnut" height="140" width="140" style="margin: 15px 10px 10px 0"></canvas>
                                    </td>
                                    <td>
                                        <table class="tile_info">
                                            <tr>
                                                <td>
                                                    <p><i class="fa fa-square blue"></i>Ranchi </p>
                                                </td>
                                                <td>24%</td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <p><i class="fa fa-square green"></i>Gayaa</p>
                                                </td>
                                                <td>20%</td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <p><i class="fa fa-square purple"></i>Asansol</p>
                                                </td>
                                                <td>1%</td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <p><i class="fa fa-square aero"></i>Nethragat</p>
                                                </td>
                                                <td>15%</td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <p><i class="fa fa-square red"></i>Others </p>
                                                </td>
                                                <td>40%</td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>


                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="x_panel tile fixed_height_320">
                        <div class="x_title">
                            <h2>Quick Settings</h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="#">Settings 1</a>
                                        </li>
                                        <li><a href="#">Settings 2</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a class="close-link"><i class="fa fa-close"></i></a>
                                </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <div class="dashboard-widget-content">
                                <ul class="quick-list">
                                    <li><i class="fa fa-calendar-o"></i><a href="#">Settings</a>
                                    </li>
                                    <li><i class="fa fa-bars"></i><a href="#">Lockdown</a>
                                    </li>
                                   
                                    <li><i class="fa fa-bar-chart"></i><a href="#">Quarantined Details</a> </li>
                                    <li><i class="fa fa-line-chart"></i><a href="#">Achievements</a>
                                    </li>
                                    <li><i class="fa fa-area-chart"></i><a href="#">Logout</a>
                                    </li>
                                </ul>

                                <div class="sidebar-widget">
                                    <h4>Increase Rate</h4>
                                    <canvas width="150" height="80" id="chart_gauge_01" class="" style="width: 160px; height: 100px;"></canvas>
                                    <div class="goal-wrapper">
                                        <span id="gauge-text" class="gauge-value pull-left">0</span>
                                        <span class="gauge-value pull-left">%</span>
                                        <span id="goal-text" class="goal-value pull-right">100%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>


            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2>Questions on COVID -19 <small>Sessions</small></h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="#">Settings 1</a>
                                        </li>
                                        <li><a href="#">Settings 2</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a class="close-link"><i class="fa fa-close"></i></a>
                                </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <div class="dashboard-widget-content">

                                <ul class="list-unstyled timeline widget">
                                    <li>
                                        <div class="block">
                                            <div class="block_content">
                                                <h2 class="title">
                                                    <a>How to Prepare ourselves for Corona Virus?</a>
                                                </h2>
                                                <div class="byline">
                                                    <span>13 hours ago</span> by COVID_FIXERS<a></a>
                                                </div>
                                                <p class="excerpt">Do not panic. While the outbreak is a serious public health concern, the majority of those who contract the coronavirus do not become seriously ill, and only a small percentage require intensive care.

 <a>Read&nbsp;More</a>
                                                </p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="block">
                                            <div class="block_content">
                                                <h2 class="title">
                                                    <a>Who is at risk for coronavirus?</a>
                                                </h2>
                                                <div class="byline">
                                                    <span>13 hours ago</span> by <a>COVID_FIXERS</a>
                                                </div>
                                                <p class="excerpt">The virus that causes COVID-19 infects people of all ages. However, evidence to date suggests that two groups of people are at a higher risk of getting severe COVID-19 disease. These are older people (that is people over 60 years old); and those with underlying medical conditions (such as cardiovascular disease, diabetes, chronic respiratory disease, and cancer).<a>Read&nbsp;More</a>
                                                </p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="block">
                                            <div class="block_content">
                                                <h2 class="title">
                                                    <a>Can the coronavirus disease spread through food?</a>
                                                </h2>
                                                <div class="byline">
                                                    <span>13 hours ago</span> by <a>COVID_FIXERS</a>
                                                </div>
                                                <p class="excerpt">Current evidence on other coronavirus strains shows that while coronaviruses appear to be stable at low and freezing temperatures for a certain period, food hygiene and good food safety practices can prevent their transmission through food.</P>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="block">
                                            <div class="block_content">
                                                <h2 class="title">
                                                    <a>Are masks effective against the coronavirus disease?</a>
                                                </h2>
                                                <div class="byline">
                                                    <span>13 hours ago</span> by <a>COVID_FIXERS</a>
                                                </div>
                                                <p class="excerpt">If you are healthy, you only need to wear a mask if you are taking care of a person with suspected 2019-nCoV infection. Wear a mask if you are coughing or sneezing. Masks are effective only when used in combination with frequent hand-cleaning with alcohol-based hand rub or soap and water. If you wear a mask, then you must know how to use it and dispose of it properly.</P>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-md-8 col-sm-8 col-xs-12">



                    <div class="row">

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Visitors location <small>geo-presentation</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="#">Settings 1</a>
                                                </li>
                                                <li><a href="#">Settings 2</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <div class="dashboard-widget-content">
                                        <div class="col-md-4 hidden-small">
                                            <h2 class="line_30">Cases in Jharkand</h2>
<h3 class="line_30">Qurantined Patients Count Details</h3>

                                            <table class="countries_list">
                                                <tbody>
                                                <tr>
                                                    <td>Ranchi</td>
                                                    <td class="fs15 fw700 text-right">24%</td>
                                                </tr>
                                                <tr>
                                                    <td>Gaya</td>
                                                    <td class="fs15 fw700 text-right">20%</td>
                                                </tr>
                                                <tr>
                                                    <td>Asansol</td>
                                                    <td class="fs15 fw700 text-right">1%</td>
                                                </tr>
                                                <tr>
                                                    <td>Netragat</td>
                                                    <td class="fs15 fw700 text-right">15%</td>
                                                </tr>
                                                <tr>
                                                    <td>Others</td>
                                                    <td class="fs15 fw700 text-right">40%</td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <iframe src="https://public.domo.com/cards/dG1jy" width="100%" height="600" marginheight="0" marginwidth="0" frameborder="0"></iframe>          </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="row">


                        <!-- Start to do list -->
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>To Do List <small>Sample tasks</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="#">Settings 1</a>
                                                </li>
                                                <li><a href="#">Settings 2</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">

                                    <div class="">
                                        <ul class="to_do">
                                            <li>
                                                <p>
                                                    <input type="checkbox" class="flat"> Clean your hands often. Use soap and water, or an alcohol-based hand rub.</p>
                                            </li>
                                            <li>
                                                <p>
                                                    <input type="checkbox" class="flat"> Maintain a safe distance from anyone who is coughing or sneezing.</p>
                                            </li>
                                            <li>
                                                <p>
                                                    <input type="checkbox" class="flat"> Don’t touch your eyes, nose or mouth.</p>
                                            </li>
                                            <li>
                                                <p>
                                                    <input type="checkbox" class="flat"> Cover your nose and mouth with your bent elbow or a tissue when you cough.</p>
                                            </li>
                                            <li>
                                                <p>
                                                    <input type="checkbox" class="flat"> Stay home if you feel unwell.</p>
                                            </li>
                                           
                                            <li>
                                                <p>
                                                    <input type="checkbox" class="flat"> If you have a fever, cough and difficulty breathing, seek medical attention. Call in advance</p>
                                            </li>
                                            <li>
                                                <p>
                                                    <input type="checkbox" class="flat"> Follow the directions of your local health authority.</p>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End to do list -->
<div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Daily active users <small>Sessions</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="#">Settings 1</a>
                                                </li>
                                                <li><a href="#">Settings 2</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                                              <img src="../../resource/images/1.jpg" >
                        </div>
                    </div>
                </div>
            </div>
        </div>
                     
                    </div>
                </div>
            </div>
        </div>

        <!-- /page content -->

        <!-- footer content include -->
        <?php include '../partPage/footer.html' ?>
        <!-- /footer content include -->
    </div>
</div>

<!-- jQuery -->
<script src="../../resource/js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="../../resource/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="../../resource/js/fastclick.js"></script>
<!-- NProgress -->
<script src="../../resource/js/nprogress.js"></script>
<!-- Chart.js -->
<script src="../../resource/js/Chart.min.js"></script>
<!-- gauge.js -->
<script src="../../resource/js/gauge.min.js"></script>
<!-- bootstrap-progressbar -->
<script src="../../resource/js/bootstrap-progressbar.min.js"></script>
<!-- iCheck -->
<script src="../../resource/js/icheck.min.js"></script>
<!-- Skycons -->
<script src="../../resource/js/skycons.js"></script>
<!-- Flot -->
<script src="../../resource/js/jquery.flot.js"></script>
<script src="../../resource/js/jquery.flot.pie.js"></script>
<script src="../../resource/js/jquery.flot.time.js"></script>
<script src="../../resource/js/jquery.flot.stack.js"></script>
<script src="../../resource/js/jquery.flot.resize.js"></script>
<!-- Flot plugins -->
<script src="../../resource/js/jquery.flot.orderBars.js"></script>
<script src="../../resource/js/jquery.flot.spline.min.js"></script>
<script src="../../resource/js/curvedLines.js"></script>
<!-- DateJS -->
<script src="../../resource/js/date.js"></script>
<!-- JQVMap -->
<script src="../../resource/js/jquery.vmap.min.js"></script>
<script src="../../resource/js/jquery.vmap.world.js"></script>
<script src="../../resource/js/jquery.vmap.sampledata.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="../../resource/js/moment.min.js"></script>
<script src="../../resource/js/daterangepicker.js"></script>
<!-- Custom Theme Scripts -->
<script src="../../resource/js/custom.min.js"></script>
</body>
</html>

