<?php
$html = file_get_contents('https://www.worldometers.info/coronavirus/?utm_campaign=homeAdvegas1?'); //get the html returned from the following url

$corona_doc = new DOMDocument();

libxml_use_internal_errors(TRUE); //disable libxml errors

if(!empty($html)){ //if any html is actually returned

	$corona_doc->loadHTML($html);
	libxml_clear_errors(); //remove errors for yucky html
	
	$corona_xpath = new DOMXPath($corona_doc);

	//get all the h2's with an id
	$corona_row = $corona_xpath->query('//div[@id]');

	if($corona_row->length > 0){
		foreach($corona_row as $row){
			echo $row->nodeValue . "<br/>"."<br>";
		}
	}
}

?>