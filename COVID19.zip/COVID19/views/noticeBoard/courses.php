<?php

session_start();

if(!isset($_SESSION['admin_name']) && !isset($_SESSION['password'])) {
    header("Location:../../index.php");
}

include ("../../src/common/DBConnection.php");

$conn=new DBConnection();



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Human Resource Management Sysytem</title>

    <!-- Bootstrap -->
    <link href="../../resource/css/bootstrap.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../../resource/css/font-awesome.css" rel="stylesheet">
    
    <!-- iCheck -->
    <link href="../../resource/css/green.css" rel="stylesheet">
    
    <!-- JQVMap -->
    <link href="../../resource/css/jqvmap.css" rel="stylesheet"/>
    <!-- bootstrap-daterangepicker -->
    <link href="../../resource/css/daterangepicker.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../../resource/css/custom.css" rel="stylesheet">
</head>
<html>
<head>
<style>
* {
  box-sizing: border-box;
}

.column {
  float: left;
  width: 50%;
 
  padding: 15px;
}

/* Clearfix (clear floats) */
.row::after {
  content: "";
  clear: both;
  display: table;
}
</style>
</head>

<body class="nav-md">
<!-- Font Awesome -->
    <link href="../../resource/css/font-awesome.css" rel="stylesheet">
<div class="container body">
    <div class="main_container">

        <!-- side and top bar include -->
        <?php include '../partPage/sideAndTopBarMenu.html' ?>
        <!-- /side and top bar include -->

        <!-- page content -->
        <div class="right_col" role="main">
            <!-- top tiles -->
            <div class="row tile_count">
               <h1  style = "font-family:Star Wars;">Online Training Courses<h2>
					<p style = "font-family:Star Wars; font-size: 18px;">Online education is not a new trend but it is becoming more popular as we speak. There are many reasons for that, affordability and flexibility being the main ones. Online education gives you the freedom to learn at your own pace, at any time and place. And as for the price, there are many online learning platforms, such as Skillshare and Udemy, that offer thousands of classes at no cost. Of course, you could also take classes on YouTube, but I prefer eLearning platforms as they offer high-quality courses, plus there are no ads and distractions there. Online learning platforms also provide a sense of community—you get to create class projects and participate in group discussions, which is especially important right now.

The amount of learning platforms is overwhelming, and once you pick one, stick to it.</p>
            <div class="column">
    <img src="../../resource/images/EL.png"  style="width:100%";"height:200px">
  </div>
			<p style = "font-family:Star Wars;">
			<h2 style = "font-family:Star Wars;"><b>
			
</li>6 Tips To Help You Get The Most Out Of Your eLearning Courses</b></h2>
<li style = "font-family:Star Wars; font-size: 18px;">1.Once you chose a platform you like, browse around and see what classes you would like to take. Be realistic, you probably won't be able to take 50 classes a month. Stick to the ones that you would enjoy the most.</li>
<li style = "font-family:Star Wars; font-size: 18px;">2.Make a schedule and add reminders to your calendar so that you won't forget about classes. Remember, that you can take classes at any time. That is the beauty of online education.</li>
<li style = "font-family:Star Wars; font-size: 18px;">3.Active participation is the key to successful learning. So create projects for your classes, complete the assignments, get feedback from your peers, collaborate with other students, ask questions, and participate in conversations.</li>
<li style = "font-family:Star Wars; font-size: 18px;">4.Apply new skills that you have learned to real-life situations.</li>
<li style = "font-family:Star Wars; font-size: 18px;">5.Have fun. Enjoy the process. And always do it your way.</li>
<li style = "font-family:Star Wars; font-size: 18px;">6.If for any reason you are not enjoying the course, quit and take another one. </li></p>
			</div>
            <!-- /top tiles -->
            

            <br />  
                                 
            <br>
                                             .
            <div class="row">
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2>ABOUT</h2>
                            <ul class="nav navbar-right panel_toolbox">
                                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                </li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="#">Settings 1</a>
                                        </li>
                                        <li><a href="#">Settings 2</a>
                                        </li>
                                    </ul>
                                </li>
                                <li><a class="close-link"><i class="fa fa-close"></i></a>
                                </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>


            
                        <div class="x_content">
                            <div class="dashboard-widget-content">

                                <ul class="list-unstyled timeline widget">
                                    <li>
                                        <div class="block">
                                            <div class="block_content">
                                                <h2 class="title">
                                                    <a>Cousera</a>
                                                </h2>
                                                <div class="byline">
                                                    <span>by Covid_Fixers</span>
                                                </div>
                                                <p class="excerpt">Coursera is a world-wide online learning platform founded in 2012 by Stanford computer science professors Andrew Ng and Daphne Koller that offers massive open online courses, specializations, and degrees.Build skills with courses from top universities like Yale, Michigan, Stanford, and leading companies like Google and IBM. 
                                                </p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="block">
                                            <div class="block_content">
                                                <h2 class="title">
                                                    <a>NPTEL</a>
                                                </h2>
                                                <div class="byline">
                                                    <span>by Covid_Fixers</span> 
                                                </div>
                                                <p class="excerpt">National Programme on Technology Enhanced Learning (NPTEL) is a project of MHRD initiated by seven Indian Institutes of Technology (Bombay, Delhi, Kanpur, Kharagpur, Madras, Guwahati and Roorkee) along with the Indian Institute of Science, Bangalore in 2003, to provide quality education to anyone interested in learning from the IITs. The main goal was to create web and video courses in all major branches of engineering and physical sciences at the undergraduate and postgraduate levels and management courses at the postgraduate level.
                                                </p>
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="block">
                                            <div class="block_content">
                                                <h2 class="title">
                                                    <a>Udemy</a>
                                                </h2>
                                                <div class="byline">
                                                    
                                                </div>
                                                <p class="excerpt">Udemy, founded in May 2010, is an American online learning platform aimed at professional adults and students. As of Jan 2020, the platform has more than 50 million students and 57,000 instructors teaching courses in over 65 languages. There have been over 295 million course enrollments. 
                                            </div>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="block">
                                            <div class="block_content">
                                                <h2 class="title">
                                                    <a>edX</a>
                                                </h2>
                                                <div class="byline">
                                                    
                                                </div>
                                                <p class="excerpt">edX is a massive open online course provider created by Harvard and MIT. It hosts online university-level courses in a wide range of disciplines to a worldwide student body, including some courses at no charge. It also conducts research into learning based on how people use its platform. 
                                                </p>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-md-8 col-sm-8 col-xs-12">

<div class="row">

                     <div class="row">
  <div class="column">
  
   <img src="../../resource/images/coursera.png" style="width:100%" ;"height:200px">
  </div>
  <div class="column">
    <img src="../../resource/images/NP.png" style="width:100%";"height:200px">
  </div>
  
</div>
 <div class="row">
  <div class="column">
    <img src="../../resource/images/u.png"  style="width:100%";"height:200px">
  </div>
  <div class="column">
    <img src="../../resource/images/edx.png" style="widtH:100%";"height:200px">
  </div>
  
</div>

                    <div class="row">

                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>TOP SITES FOR ONLINE COURSES</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="#">Settings 1</a>
                                                </li>
                                                <li><a href="#">Settings 2</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>

                                

                                        
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    

                        <!-- Start to do list -->
                        <div class="col-md-8 col-sm-6 col-xs-6">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Top Sites <small>Click on the it</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="#">Settings 1</a>
                                                </li>
                                                <li><a href="#">Settings 2</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">

                                    <div class="">
                                        <ul class="to_do">
                                            <li>
                                                <p>
                                                    <input type="checkbox" class="flat" ><a href="https://www.coursera.org/" rel="stylesheet"> Coursera</a></p>
                                            </li>
                                            <li>
                                                <p>
                                                    <input type="checkbox" class="flat"><a href="https://nptel.ac.in/course.html" rel="stylesheet">NPTEL</p>
                                            </li>
                                            <li>
                                                <p>
                                                    <input type="checkbox" class="flat"><a href="https://www.udemy.com/" rel="stylesheet">Udemy</a></p>
                                            </li>
                                            <li>
                                                <p>
                                                    <input type="checkbox" class="flat"><a href="https://www.edx.org/search?tab=course" rel="stylesheet"> edX</a></p>
                                            </li>
                                            <li>
                                                <p>
                                                    <input type="checkbox" class="flat"><a href="https://www.kaggle.com/learn/overview" rel="stylesheet">Kaggle</a></p>
                                            </li>
                                            <li>
                                                <p>
                                                    <input type="checkbox" class="flat"><a href="https://www.khanacademy.org/" rel="stylesheet">Udacity</a></p>
                                            </li>
                                           
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End to do list -->

                     
                    </div>
                </div>
            </div>
        </div>
        <!-- /page content -->

        <!-- footer content include -->
        <?php include '../partPage/footer.html' ?>
        <!-- /footer content include -->
    </div>
</div>

<!-- jQuery -->
<script src="../../resource/js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="../../resource/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="../../resource/js/fastclick.js"></script>


<!-- gauge.js -->
<script src="../../resource/js/gauge.min.js"></script>

<!-- iCheck -->
<script src="../../resource/js/icheck.min.js"></script>
<!-- Skycons -->
<script src="../../resource/js/skycons.js"></script>
<!-- Flot -->
<script src="../../resource/js/jquery.flot.js"></script>
<script src="../../resource/js/jquery.flot.pie.js"></script>
<script src="../../resource/js/jquery.flot.time.js"></script>
<script src="../../resource/js/jquery.flot.stack.js"></script>
<script src="../../resource/js/jquery.flot.resize.js"></script>
<!-- Flot plugins -->
<script src="../../resource/js/jquery.flot.orderBars.js"></script>
<script src="../../resource/js/jquery.flot.spline.min.js"></script>
<script src="../../resource/js/curvedLines.js"></script>
<!-- DateJS -->
<script src="../../resource/js/date.js"></script>
<!-- JQVMap -->
<script src="../../resource/js/jquery.vmap.min.js"></script>
<script src="../../resource/js/jquery.vmap.world.js"></script>
<script src="../../resource/js/jquery.vmap.sampledata.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="../../resource/js/moment.min.js"></script>
<script src="../../resource/js/daterangepicker.js"></script>
<!-- Custom Theme Scripts -->
<script src="../../resource/js/custom.min.js"></script>
</body>
</html>

