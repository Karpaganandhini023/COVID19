
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html	p{background-position:left;
	font-family:"Arial Rounded MT bold", Times, serif;
	font-size:20px;
	color:#FFFFFF;
	
	text-align:center;
	}
	h2{font-style:Bold;
	font-size:36px;
	color:#Tomato;
	text-align:center;
	}

h1{
font-size:50px;
color:#FFFFFF;
padding-top:60px;
}
img 
{ float: left;
width: 77px;
}

body {margin:0;
padding:0;
font-family:"Bahnschrift Light", "Bernard MT Condensed", "Berlin Sans FB Demi", "Bell MT";
width:100%;
height:100vh;
background-color:SkyBlue;
}
</style>
</style>
<body>


<!-- Header with image -->

<header class="bgimg w3-display-container  w3-grayscale-min" id="myPage" >
</header>


<!-- Add a background color and large text to the whole page -->
<div class="w3-sand w3-grayscale w3-large">

<!-- About Container -->

<style>
body {
  background-image: url('../../resource/images/i.gif');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}
</style>
 <img src="../../resource/images/i.gif">	
<div class="w3-container" id="about">
  <div class="w3-content" style="max-width:900px">
  <div class="w3-card-4 w3-margin w3-white">
  
  
    <div class="w3-container "><h2 style="color:MediumSeaGreen","font-family:verdana";><u><strong>HERE THE CURRENT UPDTAES!!!</strong></u></center></center></h1></b>
	 <a href="javascript:void(0);" title="Site Search" aria-label="Site Search"><span class="icon-search" aria-hidden="true"></span></a>
                 
				  <div class="title_right">
				                      
             <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                    <div class="input-group">
                    <form onsubmit="return search_validation()" action="https://ranchi.nic.in/" method="get">
                        <label for="search" class="hide"><h2 style="color:Tomato;"><center>Search</h2></center></label>
                        <input type="search" title="Enter Text" name="s" id="search" value="" />
                        <button type="submit" title="Search">Search<span class="icon-search" aria-hidden="true"></span></button>
                    </form>
                    </div>
					</div>
	  <h2 style="color:SlateBlue","font-family:verdana";><u><strong>HERE ARE THE SOME  OFFICIAL LINKS....!!!</h1></strong></u>
      <a href="https://www.mygov.in/covid-19/"><h2 style="color:Tomato","font-family:verdana";><strong>1.VISIT OUR GOVT.LINK-www.mygov.in</h3></a></strong>
	  <a href="https://www.mohfw.gov.in/"> <h2 style="color:Tomato","font-family:verdana";><strong>2.VISIT OUR MOHW LINK-www.mohfw.gov.in</h3></a>
	 <a href="https://play.google.com/store/apps/details?id=nic.goi.aarogyasetu&hl=en_IN">< <h2 style="color:Tomato","font-family:verdana";><strong>3.GOVT OFFICIAL -Aaarogya setu app</h3></a>
	 <a lang="hi" href="http://www.jharkhand.gov.in/"
	            "aria-label"="झारखण्ड सरकार - External Regional Language Site that opens in a new window"
	              title="झारखण्ड सरकार - External Regional Language Site that opens in a new window">
	 <h2 style="color:Tomato","font-family:verdana";><strong>4.Jharkhand-Regional language link</h2></strong></a>
    <a lang="en" href="http://www.jharkhand.gov.in/"><h2 style="color:Tomato","font-family:verdana";><strong>5.Government of Jharkhand</h2></a></strong>

	  
      
    </div>

   
 </body>
</html>

<script>
$(document).ready(function(){
 
 $('#comment_form').on('submit', function(event){
  event.preventDefault();
  var form_data = $(this).serialize();
  $.ajax({
   url:"add_comment.php",
   method:"POST",
   data:form_data,
   dataType:"JSON",
   success:function(data)
   {
    if(data.error != '')
    {
     $('#comment_form')[0].reset();
     $('#comment_message').html(data.error);
     $('#comment_id').val('0');
     load_comment();
    }
   }
  })
 });

 load_comment();

 function load_comment()
 {
  $.ajax({
   url:"fetch_comment.php",
   method:"POST",
   success:function(data)
   {
    $('#display_comment').html(data);
   }
  })
 }

 $(document).on('click', '.reply', function(){
  var comment_id = $(this).attr("id");
  $('#comment_id').val(comment_id);
  $('#comment_name').focus();
 });
 
});
</script>
<html>
<head>
<title>Notificatin_update</title>
</head>
<body>

               
                
            
			<h2 style="color:SlateBlue","font-family:verdana";><u><strong>For any technical enquiry with respect to COVID19, you may kindly email on :</strong></u></h2>
				<span class="blinking bar"><strong><a href="mailto:technicalquery.covid19@gov.in"></strong><h2 style="color:MediumSeaGreen","font-family:verdana";><strong>technicalquery.covid19@gov.in</h2></strong></a> <a href="https://www.mohfw.gov.in/pdf/AAROGYASETUIVRS1921.pdf" target="_BLANK" class="pl-80"><h2 style="color:Tomato;">Aarogya Setu IVRS</h2> <h2 style="color:MediumSeaGreen;"> <i class="fa fa-phone" aria-hidden="true"></i> 1921</a></a></h2></span>
			      <img src="../../resource/images/a.png" alt="..." class="img-circle profile_img">
			 <img src="../../resource/images/a1.png" alt="..." class="img-circle profile_img"> <a href="https://play.google.com/store/apps/details?id=nic.goi.aarogyasetu&hl=en_IN"><h3 style="color:Tomato","font-family:verdana";><strong><u>Android</u></h3></strong> </a>
			<img src="../../resource/images/a2.png" alt="..." class="img-circle profile_img"><a href = "https://apple.co/2X1KMzO"><h3 style="color:MediumSeaGreen;"> <h3 style="color:Tomato","font-family:verdana";><strong><u>iPhone</u></h3></a></strong> 
                  <span class="off-css"><h2 style="color:SlateBlue","font-family:verdana";><u><strong>Social Media Links</h2></u></strong></span>              
                 <a href="#" title="Social Media Links" class="show-social-links">
                    <span class="icon-social-link" aria-hidden="true">
                      <span class="icon-facebook"></span>
                      <span class="icon-twitter"></span>
                      <span class="icon-youtube"></span>
					  <div class="container">
		<div class="row">
			<div class="col-xs-12 text-center">
			<div class="site-meta"></div>
			</div>
		</div>
	</div>   
	</div>
			
 
                  <class="socialIcons">
                    <ul><li class="ico-social"><a title="Social Media's" id="toggleSocial" href="javascript:void(0);"></a>
						 <img src="https://ranchi.nic.in/wp-content/themes/district-theme/images/ico-facebook.png" title="Facebook | External site that opens in a new window" alt="Facebook, External Link that opens in a new window"><a href="https://www.facebook.com/deputycommisionerranchi/" target="_blank" aria-label="Facebook | External site that opens in a new window"><h2 style="color:Tomato","font-family:verdana";><strong>FACEBOOK</h2></strong></a>
                         <img src="https://ranchi.nic.in/wp-content/themes/district-theme/images/ico-twitter.png" title="Twitter | External site that opens in a new window" alt="Twitter | External site that opens in a new window"><a href="https://twitter.com/dc_ranchi" target="_blank" aria-label="Twitter | External site that opens in a new window"><h2 style="color:Tomato","font-family:verdana";><strong>Twitter</h2></strong></a>
                   
                  </li>
                    </ul>
                  </div>
                </li>