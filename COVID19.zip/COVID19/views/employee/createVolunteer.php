<?php

session_start();

if(!isset($_SESSION['admin_name']) && !isset($_SESSION['password'])) {
    header("Location:../../index.php");
}

include '../../src/common/DBConnection.php';

$conn=new DBConnection();

//$departments=$conn->getAll("SELECT * FROM `departments`");

//$designations=$conn->getAll("SELECT * FROM `employee_designations`");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>COVID19 UNDER MONITOR</title>

    <!-- Bootstrap -->
    <link href="../../resource/css/bootstrap.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="../../resource/css/font-awesome.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="../../resource/css/nprogress.css" rel="stylesheet">
    <!-- Custom Theme Style -->
    <link href="../../resource/css/custom.css" rel="stylesheet">
</head>

<body class="nav-md">
<div class="container body">
    <div class="main_container">

        <!-- side and top bar include -->
        <?php include '../partPage/sideAndTopBarMenu.html' ?>
        <!-- /side and top bar include -->

        <!-- page content -->
        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>CREATE A REGISTER</h3>
                    </div>

                    <div class="title_right">
                        <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search for...">
                                <span class="input-group-btn">
                              <button class="btn btn-default" type="button">Go!</button>
                          </span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>

                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Put your information <small>correctly</small></h2>
                                <ul class="nav navbar-right panel_toolbox">
                                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                    </li>
                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                        <ul class="dropdown-menu" role="menu">
                                            <li><a href="#">Settings 1</a>
                                            </li>
                                            <li><a href="#">Settings 2</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">

                                <form class="form-horizontal form-label-left" novalidate>

                                    <p>For alternative validation library <code></code> check out in the <a href="form.html">form page</a>
                                    </p>
                                    <span class="section">VOLUNTEER Info</span>
<div style="padding-left:16px">
<div class="container">
 <form action="createVolunteer.php" method="GET">
  <div class="row">
  <form class="form-horizontal form-label-left" novalidate>

                                   

<div class="container">
  
   <div class="item form-group">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="volunteer_id">Volunteer_id <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <input type ="number" id="Volunteer_id" value="<?php echo strtoupper(rand(10,100)); ?>"   readonly="true" maxlength="13" size="40"  type="TEXT class="form-control col-md-7 col-xs-12" data-validate-minmax="10,200" name="Volunteer_id" placeholder="Enter the Volunteer_id" required="required" type="text">
                                        </div>
                                    </div>
									<div class="item form-group">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="patientname">Volunteer_Name <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <input type ="text" id="Volunteer_Name" class="form-control col-md-7 col-xs-12" data-validate-minmax="10,20" name="Volunteer_Name" placeholder="Enter the Volunteer_name" required="required" type="text">
                                        </div>
                                    </div>
									 <div class="item form-group">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="doctor_name">District <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <select id="district_name" name="district_name">
											<option value="Ranchi">Ranchi</option>
											<option value="Bokaro">Bokaro</option>
											<option value="Simdega">Simdega</option>
											</select>
                                        </div>
                                    </div>
                                    <div class="item form-group">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="apdate">Volunteer_activity_Date <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <input type="date"  id="vadate" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="vadate" placeholder="Enter Volunteer Activity Date" required="required" type="date">
                                        </div>
                                    </div>

                                    <div class="item form-group">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="aptime">Volunteer_activity__Time <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <input type="time" id="vatime" name="vatime" required="required" placeholder="Enter Volunteer_activity Time" class="form-control col-md-7 col-xs-12">
                                        </div>
                                    </div>

                                    <div class="item form-group">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="Description">Description<span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <textarea rows="5" id="ActivityDescription" name="ActivityDescription" required="required" placeholder="Volunteer Description" class="form-control col-md-7 col-xs-12"></textarea>
                                        </div>
                                    </div>
									 <div class="item form-group">
                                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="vstatus">status <span class="required">*</span>
                                        </label>
                                        <div class="col-md-6 col-sm-6 col-xs-12">
                                            <select id="vstatus" name="vstatus">
          <option value="Finished">Finished</option>
          <option value="Not finished">Not finished</option>
		   <option value="On going">On going</option>
        </select>
                                        </div>
                                    </div>

                                    <div class="ln_solid"></div>

                                    <div class="form-group">
                                        <div class="col-md-6 col-md-offset-3">
                                            <button type="reset" class="btn btn-primary">Reset</button>
                                            <button name="btn-notice" id="btn-notice" type="submit" class="btn btn-success">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      
                                    
		
        <!-- /page content -->

        <!-- footer content include -->
        <?php include '../partPage/footer.html' ?>
        <!-- /footer content include -->
    </div>
</div>

<!-- jQuery -->
<script src="../../resource/js/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="../../resource/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="../../resource/js/fastclick.js"></script>
<!-- NProgress -->
<script src="../../resource/js/nprogress.js"></script>
<!-- validator -->
<script src="../../resource/js/validator.js"></script>
<!-- Custom Theme Scripts -->
<script src="../../resource/js/custom.min.js"></script>
</body>
</html>
<?php
$con=mysqli_connect("localhost:3308","root","","gcm");
$id=$_GET['Volunteer_id"'];
$Volunteer_Name=$_GET['Volunteer_Name'];
$district_name=$_GET['district_name'];
$vadate=$_GET['vadate'];
$vatime=$_GET['vatime'];
$ActivityDescription=$_GET['ActivityDescription'];
$vstatus=$_GET['vstatus'];
$sql="INSERT INTO volunteer (id,Volunteer_Name,district_name,vadate,vatime,ActivityDescription,vstatus)
 VALUES('$id','$Volunteer_Name','$district_name','$vadate','$vatime','$ActivityDescription','$vstatus')";
if(!mysqli_query($con,$sql))
{
echo "Not inserted";
}
else
{
echo "Inserted";

}
$select="Select * from volunteer";
$result= mysqli_query($con, $select);
$count= mysqli_num_rows($result);
$dbvalue="";
if($count < 1)
{
	echo "No more rows";
}
else
{
	echo'has rows';
}
?>

